
import os, io, json, random, calendar, datetime
from flask import Flask, render_template, request, send_file, redirect, url_for, jsonify, flash
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PyPDF2 import PdfReader, PdfWriter
import fitz  # PyMuPDF

app = Flask(__name__)
app.secret_key = "dev-key-change-me"
APP_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    pdfmetrics.registerFont(TTFont("Inter", os.path.join(APP_DIR, "static", "Inter-Regular.ttf")))
    BASE_FONT = "Inter"
except Exception:
    BASE_FONT = "Helvetica"

ATIVIDADES = {
    "Português": [
        "Leitura e interpretação de texto",
        "Produção de pequeno resumo",
        "Exercícios de ortografia e acentuação",
        "Análise de gêneros textuais",
        "Pontuação e regência verbal",
        "Identificação de figuras de linguagem",
        "Coesão e coerência textual"
    ],
    "Matemática": [
        "Operações com números inteiros",
        "Frações equivalentes e simplificação",
        "Resolução de problemas com porcentagem",
        "Equações do 1º grau",
        "Razão e proporção",
        "Perímetro e área de figuras planas",
        "Média, mediana e moda"
    ]
}

def load_config():
    with open(os.path.join(APP_DIR, "config.json"), "r", encoding="utf-8") as f:
        return json.load(f)

def save_config(cfg):
    with open(os.path.join(APP_DIR, "config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

def top_to_reportlab_y(top_px, page_height):
    return page_height - top_px

def gerar_atividades_para_materia(materia, qtd=1):
    pool = ATIVIDADES.get(materia, [])
    itens = []
    for _ in range(qtd):
        if not pool:
            break
        itens.append(random.choice(pool))
    return "; ".join(dict.fromkeys(itens))

def gerar_linhas(mes:int, ano:int, horarios:list, dias_trabalho:list, materia:str, max_linhas:int):
    cal = calendar.Calendar(firstweekday=0)
    linhas = []
    dias = [d for d in cal.itermonthdates(ano, mes) if d.month == mes]
    idx_horario = 0
    for d in dias:
        weekday = d.weekday()
        if (weekday not in dias_trabalho):
            continue
        data_str = f"{d.day:02d}/{mes:02d}"
        dia_semana = ["Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado","Domingo"][weekday]
        hor = horarios[idx_horario % len(horarios)] if horarios else ""
        idx_horario += 1
        atividades = gerar_atividades_para_materia(materia, qtd=2)
        linhas.append((data_str, dia_semana, hor, atividades, ""))
        if len(linhas) >= max_linhas:
            break
    return linhas

def desenhar_overlay(linhas, cfg):
    page_w = cfg.get("page_width", A4[0])
    page_h = cfg.get("page_height", A4[1])
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(page_w, page_h))
    c.setFont(BASE_FONT, cfg.get("font_size", 10))

    table_cfg = cfg["table"]
    x0, top_y = table_cfg["origin_top_left"]
    y = top_to_reportlab_y(top_y, page_h) - 12

    widths = table_cfg["col_widths"]
    cols = ["data","dia_semana","horario","atividades","rubrica"]
    x_positions = [x0]
    for key in cols[:-1]:
        x_positions.append(x_positions[-1] + widths[key])

    for i, row in enumerate(linhas):
        if i >= table_cfg["rows"]:
            break
        row_y = y - i * table_cfg["row_height"]
        for j, text in enumerate(row):
            col_key = cols[j]
            max_w = widths.get(col_key, 80) - 4
            if col_key == "atividades":
                words = str(text).split()
                line = ""
                dy = 0
                for w in words:
                    test = (line + " " + w).strip()
                    if c.stringWidth(test, BASE_FONT, cfg.get("font_size", 10)) <= max_w:
                        line = test
                    else:
                        c.drawString(x_positions[j] + 2, row_y - dy, line)
                        line = w
                        dy += 10
                if line:
                    c.drawString(x_positions[j] + 2, row_y - dy, line)
            else:
                c.drawString(x_positions[j] + 2, row_y, str(text))

    c.save()
    buf.seek(0)
    return buf

@app.route("/", methods=["GET"])
def index():
    cfg = load_config()
    return render_template("index.html", cfg=cfg)

@app.route("/generate", methods=["POST"])
def generate():
    try:
        mes = int(request.form.get("month"))
        ano = int(request.form.get("year"))
    except:
        return "Mês/ano inválidos", 400
    horarios_raw = request.form.get("horarios","").strip()
    horarios = [h.strip() for h in horarios_raw.split(",") if h.strip()] or ["13:00–15:00"]
    materia = request.form.get("materia","Português")
    dias_selected = request.form.getlist("dias")
    dias_trabalho = [int(d) for d in dias_selected] if dias_selected else [0,1,2,3,4]
    cfg = load_config()
    max_rows = cfg["table"]["rows"]

    if "template" not in request.files:
        return "Envie o PDF modelo.", 400
    template = request.files["template"]

    linhas = gerar_linhas(mes, ano, horarios, dias_trabalho, materia, max_rows)
    overlay_buf = desenhar_overlay(linhas, cfg)

    reader = PdfReader(template)
    writer = PdfWriter()
    page0 = reader.pages[0]
    overlay_reader = PdfReader(overlay_buf)
    overlay_page = overlay_reader.pages[0]

    page0.merge_page(overlay_page)
    writer.add_page(page0)
    for i in range(1, len(reader.pages)):
        writer.add_page(reader.pages[i])

    out_buf = io.BytesIO()
    writer.write(out_buf)
    out_buf.seek(0)
    filename = f"relatorio_{mes:02d}_{ano}.pdf"
    return send_file(out_buf, as_attachment=True, download_name=filename, mimetype="application/pdf")

@app.route("/calibrate", methods=["GET","POST"])
def calibrate():
    if request.method == "GET":
        return render_template("calibrate.html")
    if "template" not in request.files:
        return jsonify({"error":"Envie um PDF"}), 400
    template = request.files["template"]
    upload_path = os.path.join(APP_DIR, "static", "uploads", "model_to_calibrate.pdf")
    template.save(upload_path)
    doc = fitz.open(upload_path)
    page = doc.load_page(0)
    zoom = 150.0 / 72.0
    mat = fitz.Matrix(zoom, zoom)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    img_path = os.path.join(APP_DIR, "static", "uploads", "calibrate_page.png")
    pix.save(img_path)
    page_rect = page.rect
    resp = {
        "img_url": "/static/uploads/calibrate_page.png",
        "page_width_pts": page_rect.width,
        "page_height_pts": page_rect.height,
        "img_w_px": pix.width,
        "img_h_px": pix.height,
        "scale": zoom
    }
    return jsonify(resp)

@app.route("/save-calibration", methods=["POST"])
def save_calibration():
    data = request.get_json(force=True)
    clicks = data.get("clicks", [])
    page_w = data.get("page_w_pts")
    page_h = data.get("page_h_pts")
    scale = data.get("scale")
    if len(clicks) < 6:
        return jsonify({"error":"É necessário 6 cliques: origem, right data, right dia, right horario, right atividades, segunda linha point"}), 400
    pts = []
    for c in clicks[:6]:
        x_pt = c["x"] / scale
        y_pt = c["y"] / scale
        pts.append((x_pt, y_pt))
    origin = pts[0]
    x2, _ = pts[1]
    x3, _ = pts[2]
    x4, _ = pts[3]
    x5, _ = pts[4]
    _, y2 = pts[5]

    data_w = x2 - origin[0]
    dia_w = x3 - x2
    hor_w = x4 - x3
    atv_w = x5 - x4
    rubrica_w = page_w - x5
    row_h = y2 - origin[1]

    cfg = load_config()
    cfg["page_width"] = page_w
    cfg["page_height"] = page_h
    cfg["table"]["origin_top_left"] = [round(origin[0],2), round(origin[1],2)]
    cfg["table"]["row_height"] = round(row_h,2)
    cfg["table"]["col_widths"] = {
        "data": round(data_w,2),
        "dia_semana": round(dia_w,2),
        "horario": round(hor_w,2),
        "atividades": round(atv_w,2),
        "rubrica": round(rubrica_w,2)
    }
    save_config(cfg)
    return jsonify({"ok": True, "config": cfg})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
